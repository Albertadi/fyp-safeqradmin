// src/app/links/page.tsx
'use client';

import VerifiedLinks from './VerifiedLinks';

export default function VerifiedLinksPage() {
  return <VerifiedLinks />;
}
