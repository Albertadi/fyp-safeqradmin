// src/app/links/add/page.tsx
import AddVerifiedLink from '@/app/links/addlink/addVerifiedLink';

export default function AddLinkPage() {
  return <AddVerifiedLink />;
}
