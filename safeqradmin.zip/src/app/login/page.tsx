import NewLoginPage from './login'

export default function LoginPage() {
  return <NewLoginPage />
}
