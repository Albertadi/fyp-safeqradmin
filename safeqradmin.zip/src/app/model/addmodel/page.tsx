'use client';

import React from 'react';
import AddModel from '@/app/model/addmodel/addModel';

export default function AddModelPage() {
  return <AddModel />;
}
