import CreateUser from './CreateUser';

export default function Page() {
  return <CreateUser />;
}